package com.sun.tools.javac.resources;

public final class version extends java.util.ListResourceBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "full", "1.8.0_504-b01" },
            { "jdk", "1.8.0_504" },
            { "release", "1.8.0_504" },
        };
    }
}
